-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2018 at 04:24 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `udemyforum`
--

-- --------------------------------------------------------

--
-- Table structure for table `channels`
--

CREATE TABLE `channels` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `channels`
--

INSERT INTO `channels` (`id`, `title`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Laravel', 'laravel', '2018-05-10 13:23:40', '2018-05-10 13:23:40'),
(2, 'HTML5', 'html5', '2018-05-10 13:23:40', '2018-05-10 13:28:29'),
(3, 'CSS3', 'css3', '2018-05-10 13:23:40', '2018-05-10 13:23:40'),
(4, 'Javascript', 'javascript', '2018-05-10 13:23:40', '2018-05-10 13:23:40'),
(5, 'PHP', 'php', '2018-05-10 13:23:40', '2018-05-10 13:25:58'),
(6, 'Symfony', 'symfony', '2018-05-10 13:23:41', '2018-05-10 13:27:11'),
(7, 'Python', 'python', '2018-05-10 13:23:41', '2018-05-10 13:27:37'),
(8, 'Blockchain', 'blockchain', '2018-05-10 13:23:41', '2018-05-10 13:28:19');

-- --------------------------------------------------------

--
-- Table structure for table `discussions`
--

CREATE TABLE `discussions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `channel_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `discussions`
--

INSERT INTO `discussions` (`id`, `user_id`, `channel_id`, `title`, `slug`, `content`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'Laravel Sed ut perspiciatis unde omnis iste natus error sit', 'laravel-sed-ut-perspiciatis-unde-omnis-iste-natus-error-sit', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '2018-05-10 13:23:41', '2018-05-10 13:23:41'),
(2, 1, 2, 'VueJs Sed ut perspiciatis unde omnis iste natus error sit', 'vuejs-sed-ut-perspiciatis-unde-omnis-iste-natus-error-sit', 'VueJs Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '2018-05-10 13:23:41', '2018-05-10 13:23:41'),
(3, 1, 2, 'Laravel1 Sed ut perspiciatis unde omnis iste natus error sit', 'laravel1-sed-ut-perspiciatis-unde-omnis-iste-natus-error-sit', 'Laravel Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '2018-05-10 13:23:41', '2018-05-10 13:23:41'),
(4, 1, 5, 'Vue Sed ut perspiciatis unde omnis iste natus error sit', 'vue-sed-ut-perspiciatis-unde-omnis-iste-natus-error-sit', 'vue Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '2018-05-10 13:23:41', '2018-05-10 13:23:41'),
(5, 3, 1, 'Using str_limit to restrict a string to a certain length', 'using-str-limit-to-restrict-a-string-to-a-certain-length', 'The str_limit is autoloaded and available in both your application code and your views. Here is a simple example demonstrating the default use case. The first parameter is your string and the second is the length you want to trim it too. In this situation seven characters:\r\n\r\n```php\r\n$value = str_limit(\'This string is really really long.\', 7);\r\n\r\n// This st...\r\n```\r\nThis helper also includes a third parameter so you change the ending on the trimmed string. For instance, pretend you want to have an arrow instead of three dots. That can be setup like this:\r\n\r\n```php\r\n$value = str_limit(\'This string is really really long.\', 7, \'&raquo\');\r\n\r\n// This st»\r\n```\r\nIf you want to learn more about this helper look at the Illuminate\\Support\\Str class which is where the underlying code is:\r\n\r\n```php\r\npublic static function limit($value, $limit = 100, $end = \'...\')\r\n{\r\n    if (mb_strwidth($value, \'UTF-8\') <= $limit) {\r\n        return $value;\r\n    }\r\n\r\n    return rtrim(mb_strimwidth($value, 0, $limit, \'\', \'UTF-8\')).$end;\r\n}\r\n```\r\n>    The first if checks to see if the string is less than the limit using the Multi-Byte mb_strwidth PHP  \r\n>     function. Finally, it does a right trim and the Multi-Byte mb_strimwidth to truncate the string to a \r\n>     specific length.', '2018-05-10 13:36:55', '2018-05-10 13:36:55');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(10) UNSIGNED NOT NULL,
  `reply_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(65, '2014_10_12_000000_create_users_table', 1),
(66, '2014_10_12_100000_create_password_resets_table', 1),
(67, '2018_05_07_100657_create_oauth_identities_table', 1),
(68, '2018_05_07_151314_create_channels_table', 1),
(69, '2018_05_07_151355_create_discussions_table', 1),
(70, '2018_05_07_151430_create_replies_table', 1),
(71, '2018_05_08_160309_create_likes_table', 1),
(72, '2018_05_09_093016_create_watchers_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_identities`
--

CREATE TABLE `oauth_identities` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `provider_user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_identities`
--

INSERT INTO `oauth_identities` (`id`, `user_id`, `provider_user_id`, `provider`, `access_token`, `created_at`, `updated_at`) VALUES
(1, 3, '2880256', 'github', 'cbcf39e1444c86db23bc7ae83a6925123d2c5e5a', '2018-05-10 13:24:26', '2018-05-10 13:30:20');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE `replies` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `discussion_id` int(10) UNSIGNED NOT NULL,
  `best_answer` tinyint(1) NOT NULL DEFAULT '0',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `replies`
--

INSERT INTO `replies` (`id`, `user_id`, `discussion_id`, `best_answer`, `content`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 0, 'Lorem ipsum dolor sit amet', '2018-05-10 13:23:41', '2018-05-10 13:23:41'),
(3, 2, 3, 0, 'Lorem ipsum dolor sit amet', '2018-05-10 13:23:41', '2018-05-10 13:23:41'),
(4, 4, 4, 0, 'Lorem ipsum dolor sit amet', '2018-05-10 13:23:41', '2018-05-10 13:23:41');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `points` bigint(20) NOT NULL DEFAULT '50',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `avatar`, `admin`, `points`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'http://udemyforum.test/avatars/avatar.png', 1, 35, 'admin@forum.test', '$2y$10$MKS.ojsYFR9b6Ii/Zaivyul9NgLaOiCHcArfIbRMvwdogSWEFxFy.', 'PZTqYEhrqE7j7Yl6VwU0aWh2rXQ8FCGjd9cu699EYhbWhmemNDNcg7ATtiGT', '2018-05-10 13:23:40', '2018-05-10 13:38:59'),
(2, 'Ivan', 'http://udemyforum.test/avatars/avatar.png', 0, 50, 'ivan@forum.test', '$2y$10$G2USQAfyiXu0ii7CP7M8/eNWxOX4eEX2K1M7N6Zc6vJLtMS1hLP4K', NULL, '2018-05-10 13:23:40', '2018-05-10 13:23:40'),
(3, 'TopalovR', 'https://avatars0.githubusercontent.com/u/2880256?v=4', 0, 50, 'rumen_topalov@yahoo.com', NULL, 'x3ebiz6OwrVR8wePHN4MqvHr8Ttc5QcOpavYl5CQmmmVbgFx6Mg0CpaS1Hwl', '2018-05-10 13:24:26', '2018-05-10 13:24:26'),
(4, 'Sisi', 'http://udemyforum.test/avatars/avatar.png', 0, 50, 'sisi@abv.bg', '$2y$10$LPN7.9aSGwYZqt6X3YsIqOYI3oBqWg7L2VtbBVmZ3GDRqnw1rsYeO', 'b0YFnmeNjnNigvtflFTtM2M9q0ux0zxHhvZ13y3lMB0QHApTpQZ6Fdu0D9o6', '2018-05-10 13:25:05', '2018-05-10 13:25:05');

-- --------------------------------------------------------

--
-- Table structure for table `watchers`
--

CREATE TABLE `watchers` (
  `id` int(10) UNSIGNED NOT NULL,
  `discussion_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `channels`
--
ALTER TABLE `channels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discussions`
--
ALTER TABLE `discussions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_identities`
--
ALTER TABLE `oauth_identities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `watchers`
--
ALTER TABLE `watchers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `channels`
--
ALTER TABLE `channels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `discussions`
--
ALTER TABLE `discussions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `oauth_identities`
--
ALTER TABLE `oauth_identities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `watchers`
--
ALTER TABLE `watchers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
