-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2018 at 02:49 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `photosell`
--

-- --------------------------------------------------------

--
-- Table structure for table `markets`
--

CREATE TABLE `markets` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `markets`
--

INSERT INTO `markets` (`id`, `title`, `photo`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Photo 1', 'photo1_1519222013.jpeg', 'About Photo 1', '2018-02-21 12:06:53', '2018-02-21 12:06:53'),
(2, 'Photo 2', 'photo2_1519222035.jpeg', 'About Photo 2', '2018-02-21 12:07:15', '2018-02-21 12:07:15'),
(3, 'Photo 3', 'photo3_1519222057.jpg', 'About Photo 3', '2018-02-21 12:07:37', '2018-02-21 12:07:37'),
(4, 'Photo 4', 'photo4_1519222080.jpg', 'About Photo 4', '2018-02-21 12:08:00', '2018-02-21 12:08:00'),
(5, 'Photo 5', 'photo5_1519222098.jpeg', 'About Photo 5', '2018-02-21 12:08:18', '2018-02-21 12:08:18'),
(6, 'Photo 6', 'photo6_1519222115.jpeg', 'About Photo 6', '2018-02-21 12:08:35', '2018-02-21 12:08:35'),
(7, 'Photo 7', 'photo7_1519222133.jpeg', 'About Photo 7', '2018-02-21 12:08:53', '2018-02-21 12:08:53'),
(8, 'Photo 8', 'photo8_1519222149.jpeg', 'About Photo 8', '2018-02-21 12:09:09', '2018-02-21 12:09:09'),
(9, 'Photo 9', 'photo9_1519222170.jpeg', 'About Photo 9', '2018-02-21 12:09:30', '2018-02-21 12:09:30'),
(10, 'Photo 10', 'photo10_1519222185.jpeg', 'About Photo 10', '2018-02-21 12:09:45', '2018-02-21 12:09:45'),
(11, 'Photo 11', 'photo11_1519222205.jpg', 'About Photo 11', '2018-02-21 12:10:05', '2018-02-21 12:10:05'),
(12, 'Photo 12', 'photo12_1519222221.png', 'About Photo 12', '2018-02-21 12:10:21', '2018-02-21 12:10:21'),
(13, 'Photo 13', 'photo13_1519222238.jpeg', 'About Photo 13', '2018-02-21 12:10:38', '2018-02-21 12:10:38'),
(14, 'Photo 14', 'photo14_1519222252.jpeg', 'About Photo 14', '2018-02-21 12:10:52', '2018-02-21 12:10:52'),
(15, 'Photo 15', 'photo15_1519222266.png', 'About Photo 15', '2018-02-21 12:11:06', '2018-02-21 12:11:06'),
(16, 'Photo 16', 'photo16_1519222285.jpeg', 'About Photo 16', '2018-02-21 12:11:25', '2018-02-21 12:11:25'),
(17, 'Photo 17', 'photo17_1519222301.jpeg', 'About Photo 17', '2018-02-21 12:11:41', '2018-02-21 12:11:41'),
(18, 'Photo 18', 'photo18_1519222316.jpeg', 'About Photo 18', '2018-02-21 12:11:56', '2018-02-21 12:11:56'),
(19, 'Photo 19', 'photo19_1519299636.jpeg', 'About photo 19', '2018-02-22 09:40:36', '2018-02-22 09:40:36'),
(20, 'Photo 20', 'photo20_1519299736.jpeg', 'About photo 20', '2018-02-22 09:42:16', '2018-02-22 09:42:16');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_02_13_094540_create_markets_table', 1),
(4, '2018_02_15_062649_create_messages_table', 2),
(5, '2018_02_19_083045_create_payments_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Rumen', 'rumen6611@abv.bg', '$2y$10$TKWYhHqW.2imfzpWp0FK5evxBzMVLDZH.DOUkJBVVOL7owzWANmha', '8ZTYMB3PWeZHhkn3gqwdDpGKv6OrQTcTpMayWxFUBBkHf18nSYpiewYt4O0E', '2018-02-14 17:47:02', '2018-02-14 17:47:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `markets`
--
ALTER TABLE `markets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `markets`
--
ALTER TABLE `markets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
