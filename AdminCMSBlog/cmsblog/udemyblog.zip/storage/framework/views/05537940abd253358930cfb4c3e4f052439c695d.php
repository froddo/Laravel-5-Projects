<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            All categories
        </div>
        <div class="panel-body">
            <table class="table table-hover">

                <thead>
                    <th>Category name</th>
                    <th>Edit category</th>
                    <th>Delete category</th>
                </thead>

                <tbody>
                <?php if($categories->count() > 0): ?>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->name); ?></td>
                            <td><a href="<?php echo e(route('category.edit',[$category->id])); ?>"  class="btn btn-primary btn-xs"><i class="fas fa-pencil-alt"></i> Edit</a></td>
                            <td>
                                <form action="<?php echo e(route('category.destroy',[$category->id])); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger btn-xs "><i class="fas fa-ban"></i> Delete</button>
                                </form>
                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <th colspan="5" class="text-center">No category found</th>
                    </tr>

                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>