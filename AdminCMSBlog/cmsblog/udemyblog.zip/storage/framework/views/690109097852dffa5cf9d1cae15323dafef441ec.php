<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            Users
        </div>
        <div class="panel-body">
            <table class="table table-hover">

                <thead>
                <th>Image</th>
                <th>Name</th>
                <th>Permissions</th>
                <th>Delete</th>
                </thead>

                <tbody>
                <?php if($users->count() > 0): ?>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <img src="<?php echo e(asset($user->profile->avatar)); ?>" width="60px" height="60px" style="border-radius: 50%;">

                            </td>
                            <td>
                                <?php echo e($user->name); ?>


                            </td>
                            <td>
                                <?php if($user->admin): ?>
                                    <a href="<?php echo e(route('users-not.admin', [$user->id])); ?>" class="btn btn-danger btn-xs">Make Not Admin</a>

                                <?php else: ?>
                                    <a href="<?php echo e(route('users.admin', [$user->id])); ?>" class="btn btn-success btn-xs">Make Admin</a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(Auth::id() !== $user->id): ?>
                                <form action="<?php echo e(route('user.destroy',[$user->id])); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger btn-xs "><i class="fas fa-trash-alt"></i> Delete</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>
                    <tr>
                        <th colspan="5" class="text-center">No users found</th>
                    </tr>

                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>