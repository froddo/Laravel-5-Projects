<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            All tags
        </div>
        <div class="panel-body">
            <table class="table table-hover">

                <thead>
                <th>Tag name</th>
                <th>Edit tag</th>
                <th>Delete tag</th>
                </thead>

                <tbody>
                <?php if($tags->count() > 0): ?>

                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($tag->tag); ?></td>
                            <td><a href="<?php echo e(route('tag.edit',[$tag->id])); ?>"  class="btn btn-primary btn-xs"><i class="fas fa-pencil-alt"></i> Edit</a></td>
                            <td>
                                <form action="<?php echo e(route('tag.destroy',[$tag->id])); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger btn-xs "><i class="fas fa-ban"></i> Delete</button>
                                </form>
                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <th colspan="5" class="text-center">No tags found</th>
                    </tr>

                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>