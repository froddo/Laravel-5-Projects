<?php $__env->startSection('title', 'Хоби'); ?>

<?php $__env->startSection('sidebar'); ?>
    <div class="album py-5 bg-light">
        <div class="container">

            <div class="row">
                <?php if(count($post) > 0): ?>

                    <div class="col-md-8">
                        <div class="card mb-4 box-shadow">
                            <div class="card-body">
                                <img class="card-img-top" src="/slider/img/tea.jpg">
                                <h4 class="card-title text-center text-info"><?php echo e($post->title); ?></h4>
                                <p class="card-text"><?php echo e($post->description); ?></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <a class="btn btn-sm btn-outline-secondary" href="/hobbies">Go Back</a>
                                        <a href="/post/<?php echo e($post->id); ?>/edit" class="btn btn-sm btn-outline-success">Edit</a>
                                        <form action="<?php echo e(route('delete.post',$post->id)); ?>" method="post">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <button class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    </div>
                                    <small class="text-right">Written on: <?php echo e($post->created_at); ?>, By: <strong>Rumen Topalov</strong></small>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <p>Няма намерен пост!</p>
                <?php endif; ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>