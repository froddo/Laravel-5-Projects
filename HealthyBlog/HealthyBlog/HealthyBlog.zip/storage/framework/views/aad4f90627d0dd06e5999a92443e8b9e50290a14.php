<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    You are logged in!
                    <?php if(Auth::user()->name == "Rumen Topalov" && Auth::user()->id == 1): ?>
                        <h2>Messages</h2>
                        <?php if(count($message) > 0): ?>
                            <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul class="list-group">

                                    <li class="list-group-item">
                                        <form action="<?php echo e(route('delete.message',$messages->id)); ?>" method="post">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <button class="btn btn-sm btn-danger pull-right">Delete</button>
                                        </form>
                                        <span class="text-danger">Name:</span> <?php echo e($messages->name); ?>

                                    </li>
                                    <li class="list-group-item"><span class="text-danger">Email:</span> <?php echo e($messages->email); ?></li>
                                    <li class="list-group-item"><span class="text-danger">Message:</span> <?php echo e($messages->message); ?></li>
                                    <li class="list-group-item"><span class="text-danger">Created:</span> <?php echo e($messages->created_at); ?></li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <p class="alert alert-success">No message yet!</p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>