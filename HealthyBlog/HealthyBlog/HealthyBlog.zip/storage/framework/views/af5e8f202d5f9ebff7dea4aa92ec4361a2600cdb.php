<?php $__env->startSection('title', 'Блог'); ?>

<?php $__env->startSection('content'); ?>

<main role="main">
    <div class="jumbotron text-center">
        <div class="container">
            <h1 class="display-5">Влиянието на природата върху човешкия дух</h1>
            <hr class="my-4">
            <p class="lead">Колкото повече даваш на природата от себе си, като я съзерцаваш, боготвориш и цениш, толкова повече тя ще ти връща.</p>
            <a href="<?php echo e('/post'); ?>" class="btn btn-primary pull-center">
                <i class="fa fa-pencil"></i> Add Post
            </a>
        </div>
    </div>
    <?php if(count($post) > 0): ?>
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <h3><strong><?php echo e($posts->title); ?></strong></h3>
                <hr>
                <h5 class="text-dark"><?php echo e($posts->description); ?></h5>
                <div class="btn-group">
                    <a href="/post/<?php echo e($posts->id); ?>/edit" class="btn btn-sm btn-outline-success">Edit</a>
                    <form action="<?php echo e(route('delete.post',$posts->id)); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button class="btn btn-sm btn-outline-danger">Delete</button>
                    </form>
                </div>
                <br>
                <small class="text-right">Written on: <?php echo e($posts->created_at); ?>, By: <strong>Rumen Topalov</strong></small>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <p class="alert alert-success">Няма намерен пост!</p>
    <?php endif; ?>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>